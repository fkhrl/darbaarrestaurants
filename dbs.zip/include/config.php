<?php
include './cms-admin/class/db_Class.php';
?>