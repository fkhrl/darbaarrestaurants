<div class="col  col--12  col--center  text--centre">
    <address><?= html_entity_decode($site_basic_info[0]->address); ?></address>
    <a href="mailto:info@darbaarrestaurants.com" class="contact"> <?= $site_basic_info[0]->email; ?></a>
    <span> | </span>
    <a href="tel:02074224100" class="contact js-phone-event"><?= $site_basic_info[0]->phone; ?></a>
    <span> | </span>
    <a href="https://www.facebook.com/DarbaarbyAbdul/" target="_blank" class="social"><i class="icon-facebook"></i></a>
    <span> | </span>
    <a href="https://twitter.com/DarbaarbyAbdul" target="_blank" class="social" ><i class="icon-twitter"></i></a>
    <span> | </span>
    <a href="https://instagram.com/darbaarbyabdul/" target="_blank" class="social" ><i class="icon-instagram"></i></a>

    <a href="http://www.skeletonit.com/" target="_blank" class="siteby">Site by Propeller</a>
</div>