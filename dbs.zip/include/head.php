<meta charset="utf-8">
        <title><?= $site_basic_info[0]->site_name;?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta name="description" content="<?= $site_basic_info[0]->description;?>">
        <meta name="keywords" content="<?= $site_basic_info[0]->keywords;?>">
        <meta name="author" content="Skeletonit">


        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">



        <link rel="stylesheet" href="assets/css/main.css">