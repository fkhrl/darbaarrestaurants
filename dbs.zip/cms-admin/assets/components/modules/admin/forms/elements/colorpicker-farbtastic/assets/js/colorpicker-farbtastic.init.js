(function($)
{
	// farbtastic colorpicker
	if ($('#colorpicker').length) 
		$('#colorpicker').farbtastic('#colorpickerColor');
})(jQuery);